#!/bin/bash
echo "Uninstalling ReaxVisual..."
echo "Removing: $(pwd)"
read -p "Are you sure? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
rm -rf "$(pwd)"
echo "ReaxVisual uninstalled."
fi
