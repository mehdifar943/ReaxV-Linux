ReaxVisual - Molecular Visualization Tool
=========================================

INSTALLATION:
1. Extract this folder anywhere
2. Run: ./ReaxV

NO ADDITIONAL DEPENDENCIES NEEDED!
- Java Runtime included
- JavaFX included
- Works on any Linux system

SYSTEM REQUIREMENTS:
- Linux (64-bit)
- X11 display
- 2GB RAM minimum

TROUBLESHOOTING:
If molecules don't appear:
- The application is using software rendering
- This works on all systems but may be slower
- For better performance, ensure OpenGL drivers are installed

CONTACT:
[Your contact info here]
